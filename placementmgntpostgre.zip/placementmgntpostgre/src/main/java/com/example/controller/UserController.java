package com.example.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.entity.UserEntity;
import com.example.exception.ResourceNotFoundException;
import com.example.repository.UserRepository;

@RestController
@RequestMapping("/api/v1/")
public class UserController {
	
	@Autowired
	private UserRepository repo;
	
	@GetMapping("/users")
	public List<UserEntity>getAllUsers(){
		return repo.findAll();
	}
	
	@PostMapping("/users")
	public UserEntity createUser(@RequestBody UserEntity userentity) {
		return repo.save(userentity);
	}
	
	@GetMapping("/users/{id}")
	public ResponseEntity<UserEntity> getUserById(@PathVariable Long id){
		UserEntity userentity=repo.findById(id)
				.orElseThrow(()-> new ResourceNotFoundException("user not found with this id:"+id));
		return ResponseEntity.ok(userentity);
	}
	
	@PutMapping("/users/{id}")
	public ResponseEntity<UserEntity> updateUser(@PathVariable Long id,@RequestBody UserEntity userdetails){
		UserEntity userentity=repo.findById(id)
				.orElseThrow(()-> new ResourceNotFoundException("user not found with this id:"+id));
		userentity.setName(userdetails.getName());
		userentity.setType(userdetails.getType());
		userentity.setPassword(userdetails.getPassword());
		
		UserEntity updateduser=repo.save(userentity);
		return ResponseEntity.ok(updateduser);
	}
	
	@DeleteMapping("/users/{id}")
	public ResponseEntity<Map<String,Boolean>> deleteUser(@PathVariable Long id){
		UserEntity userentity=repo.findById(id)
		    .orElseThrow(()-> new ResourceNotFoundException("user not found with this id:"+id));
		
		repo.delete(userentity);
		Map<String,Boolean> response=new HashMap<>();
		response.put("deleted",Boolean.TRUE);
		return ResponseEntity.ok(response);
		
				
			
			
	}
	
	

}
